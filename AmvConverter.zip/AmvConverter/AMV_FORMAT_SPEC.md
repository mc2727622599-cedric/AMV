# AMV 文件格式逆向分析报告

> 分析样本：`DEMO2.amv`（6,271,794 字节，160×120，16 fps，1488 帧）
> 本报告中的每一项数值都已通过解析真实样本 + FFmpeg 复现验证。

AMV（"Actions Media Video"）是一种廉价 MP3/MP4 播放器（采用 Actions / S1MP3 等
方案的小屏设备）使用的私有视频封装。它**长得像 AVI，但故意破坏了若干 RIFF 约定**，
所以标准 AVI 解析器无法打开它。

---

## 1. 顶层结构

```
"RIFF"  <u32 size>  "AMV "                 ← 注意 form-type 是 "AMV" + 一个空格
  "LIST" <u32 size> "hdrl"
      "amvh" <u32 56> [主头, 见 §2]
      "LIST" <u32 size> "strl"             ← 视频流
          "strh" <u32 0x38> [...]          ← 几乎全为 0
          "strf" <u32 0x24> [...]          ← 几乎全为 0
      "LIST" <u32 size> "strl"             ← 音频流
          "strh" <u32 0x30> [...]          ← 几乎全为 0
          "strf" <u32 0x14> [WAVEFORMATEX, 见 §4]
  "LIST" <u32 size> "movi"
      ( "00dc" <u32 size> <视频帧>         ← 每帧一对，见 §3
        "01wb" <u32 size> <音频块> )*      ← 每个视频帧后紧跟一块音频，见 §4
  "AMV_END_"                               ← 8 字节 ASCII 文件结束标记
```

### 与标准 AVI 的关键区别（这些就是"私有"之处）
1. **form-type 是 `"AMV "`**（含尾随空格），不是 `"AVI "`。
2. **`RIFF` / `LIST` 头里的 size 字段几乎都被写成 0**（哨兵值），不可信。解析时
   必须靠"识别已知 chunk 标签 + 读取每个数据 chunk 自带的 size"来逐块前进。
3. **chunk 之间没有 16-bit 字对齐填充。** 标准 AVI 在奇数长度 chunk 后补 1 个
   填充字节，AMV **不补**。（样本中第一块音频长 697 字节为奇数，下一块视频紧贴其后
   开始，验证了这一点。）
4. **主头是 `amvh` 而不是 `avih`**，字段布局也不同（见 §2）。
5. 视频 chunk id 为 `00dc`（流 0，"dc" = DIB compressed），音频为 `01wb`
   （流 1，"wb" = wave bytes）。
6. **文件末尾有 8 字节 ASCII 串 `AMV_END_`**（`41 4D 56 5F 45 4E 44 5F`）。

---

## 2. `amvh` 主头（56 字节，14 个小端 u32）

| 偏移 | 字段 | 样本(DEMO2) | FFmpeg 复现规则 |
|------|------|-------------|------------------|
| +0x00 | usPerFrame（每帧微秒） | 62500 | `round(1_000_000 / fps)`（16fps→62500, 15fps→66667, 30fps→33333） |
| +0x04..+0x1C | 保留（7×u32） | 0 | 全 0 |
| +0x20 | width  | 160 | 视频宽 |
| +0x24 | height | 120 | 视频高 |
| +0x28 | fps    | 16  | 帧率 |
| +0x2C | flag（恒为 1） | 1 | 常量 1 |
| +0x30 | 时长-分 | 0 | `floor(总秒数 / 60)` |
| +0x34 | 时长-秒 | 289 | `总秒数 % 60` |

> 注：样本 DEMO2 的 +0x34 写了 289，与"1488 帧 ÷ 16fps = 93 秒"对不上——这是
> OEM 转换工具留下的不一致元数据，播放器并不依赖它。FFmpeg 写出的头是自洽的。

---

## 3. 视频编码：AMV-MJPEG（FFmpeg codec id = `amv`）

AMV 的视频是一种**被裁剪过的 Motion-JPEG**：

- 像素格式 **`yuvj420p`**（全范围 YUV 4:2:0，色彩矩阵 bt470bg）。
- 每一帧只保留：
  ```
  FF D8                  ← SOI (Start Of Image)
  <熵编码扫描数据...>     ← 紧跟 SOI，没有任何段标记
  FF D9                  ← EOI (End Of Image)
  ```
  **帧内不包含** APP0/JFIF、DQT（量化表）、DHT（霍夫曼表）、SOF0、SOS 等标准 JPEG
  段。逐字节扫描样本帧只能找到 `FF D8`（开头）和 `FF D9`（结尾）两个标记，中间全是
  熵数据。
- 之所以能省掉这些表，是因为**解码器内置了固定的量化表和霍夫曼表**（即标准 JPEG
  Annex-K 表）。这也正是普通 JPEG 解码器无法解码 AMV 帧的根本原因——它们会去帧里
  找表，而表并不存在。
- 尺寸约束：宽高基于 8×8 块；高度建议为 **16 的倍数**（部分硬件解码器对非 16 倍数的
  高度会出错；FFmpeg 默认拒绝，需 `-strict -1` 才放行，例如 120）。宽度需为偶数，
  实践中取 16 的倍数。常见分辨率：160×120、128×128、208×176、320×240。

---

## 4. 音频编码：IMA-ADPCM "AMV" 变体（FFmpeg codec id = `adpcm_ima_amv`）

- 单声道，**采样率固定 22050 Hz**（FFmpeg 的 `adpcm_ima_amv` 编码器只接受 22050）。
- `strf` 里的 `WAVEFORMATEX`（20 字节）**故意"伪装"成 16-bit PCM**：

  | 字段 | 值 |
  |------|----|
  | wFormatTag | 1（PCM，假的） |
  | nChannels | 1 |
  | nSamplesPerSec | 22050 |
  | nAvgBytesPerSec | 44100 |
  | nBlockAlign | 2 |
  | wBitsPerSample | 16 |
  | cbSize | 0 |

  解码器无视这些值，按 AMV-ADPCM 处理。

- **每个视频帧后面紧跟一块 `01wb` 音频**，即一帧画面 = 1/fps 秒的音频。
  样本：22050 / 16 = 1378.125 → 块头声明 1378 个采样（OEM 工具取整，会累积极小漂移）。
- 每个 `01wb` 块以 **8 字节块头**开始，随后是 4-bit ADPCM 半字节流：

  ```
  +0x00  int16(LE)  predictor    起始预测值（首采样）
  +0x02  uint8      step_index   起始步长索引
  +0x03  uint8      reserved     0
  +0x04  uint32(LE) nb_samples   本块解码后的采样数
  +0x08  ...        nibble 流
  ```
  （样本首块：`00 00 00 00 62 05 00 00 ...` → predictor=0, step=0, nb_samples=0x562=1378。）

### ⚠️ 帧率与采样率的硬约束（做转换器时最容易踩的坑）
因为"每帧采样数 = 22050 / fps"必须为整数，而采样率被锁死在 22050，所以
**fps 必须能整除 22050**。22050 = 2·3²·5²·7²，常用合法 fps：
`10, 14, 15, 18, 21, 25, 30 …`。

**16 fps 无法用 FFmpeg 实现**（22050/16 不是整数）——尽管 OEM 工具能做（它直接取整）。
本项目默认用 **15 fps**（最接近样本的 16 fps）。FFmpeg 的 muxer 还要求显式
`-block_size = 22050/fps`（例如 15fps→1470, 30fps→735），否则会报
"Invalid audio frame size"。

### 其它 muxer 约束
- **AMV 必须恰好 2 条流**（1 视频 + 1 音频）。若源 MP4 无音轨，必须注入静音
  （`-f lavfi -i anullsrc=channel_layout=mono:sample_rate=22050`）。

---

## 5. 一句话总结转换配方（已验证可被 FFmpeg 解码、结构与样本一致）

```bash
ffmpeg -y -i INPUT.mp4 \
  -vf "scale=W:H:force_original_aspect_ratio=decrease,\
pad=W:H:(ow-iw)/2:(oh-ih)/2:black,fps=FPS,format=yuvj420p" \
  -c:v amv -strict -1 \
  -c:a adpcm_ima_amv -ar 22050 -ac 1 -block_size $((22050/FPS)) \
  -f amv OUTPUT.amv
# 无音轨时追加: -f lavfi -i anullsrc=channel_layout=mono:sample_rate=22050 \
#              -map 0:v:0 -map 1:a:0 -shortest
# 约束: FPS ∈ {15,18,25,30,...}（整除22050）; W 为16倍数; H 为16倍数或用 -strict -1 放行(如120)
```

安卓端即基于此配方，用 **FFmpegKit**（FFmpeg 的安卓封装）执行。详见 `README.md`。

---

## 6. 反向转换（AMV → MP4）

把 AMV 还原为通用视频也走 FFmpeg：它能把这种“私有破坏过”的容器当作 AVI 变体 demux，
并用内置解码器解出 MJPEG（`amv`）视频与 IMA-ADPCM（`adpcm_ima_amv`）音频，再重编码为
H.264 + AAC 的 MP4。已用样本 `DEMO2.amv` 实测：

- `ffprobe` 识别为两条流（video=amv 160×120@16、audio=adpcm_ima_amv 22050/mono）；
  容器 `duration` 显示 `N/A`（与 §2 提到的头部元数据不可靠一致）。
- 转换时 FFmpeg 自行绕过头里 `scale/rate = 0/0` 的无效字段（仅告警），
  产物 MP4 时长被正确算成 **93.0s = 1488 帧 / 16fps**。

验证过的反向配方：

```bash
ffmpeg -y -i 输入.amv \
  -c:v libx264 -pix_fmt yuv420p -crf 23 \
  -c:a aac -b:a 96k -ar 22050 \
  -movflags +faststart -f mp4 输出.mp4
```

要点：
- AMV 视频是 `yuvj420p`（全范围），统一转 `yuv420p` 以获得最广播放器兼容性。
- 进度无法依赖容器时长（`N/A`），改用 `ffprobe -count_frames` 数出的实际帧数作分母。
- `libx264` 仅存在于 ffmpeg-kit 的 **full / full-gpl** 构建；**min** 构建无视频编码器，
  反向会失败（正向 MP4→AMV 不受影响）。
