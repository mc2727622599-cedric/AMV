# AMV Converter (安卓)

把 **MP4** 转换为廉价 MP3/MP4 播放器（电子相册、老人机、儿童相机等）使用的私有 **`.amv`** 格式的安卓 App。

格式本身是通过逆向样本文件 `DEMO2.amv` 得出的，完整规格见同目录的 **`AMV_FORMAT_SPEC.md`**。

---

## 如何得到 APK 安装包

本项目交付的是**源码工程**，因为构建一个能真正安装、真正完成转换的 APK 必须有
Android SDK 和 FFmpegKit 的原生库——这两样无法塞进一个凭空生成的 .apk 里。下面三条
任选其一，都能产出可直接安装的 `app-debug.apk`。

> ⚠️ 转换功能依赖一个叫 **FFmpegKit** 的库。**方式 A（云端构建）会自动下载它，你无需手动准备**；
> 只有方式 B / C（在自己电脑上构建）才需要手动把它的 AAR 放进 `app/libs/`
> （见后面“一次性准备”一节，那里给了直接下载地址）。

### 方式 A — GitHub Actions 云端构建（本机零安装，已内置）

工程里已带好 `.github/workflows/build-apk.yml`。流程：

1. 把整个工程推到一个 GitHub 仓库（**不用管那个库文件，云端会自动下载**）。
2. 打开仓库的 **Actions** 标签页，等 “Build APK” 跑完（约几分钟）。
3. 进入该次运行页面，最底部 **Artifacts** 区下载 `AmvConverter-debug-apk`，解压即得 `app-debug.apk`。

CI 会自动安装 Android SDK、自动下载 FFmpegKit 库、并完成编译，你本地什么都不用装。

### 方式 B — Android Studio 一键（最直观）

1. 用 Android Studio 打开本工程（首次会自动下载 SDK / Gradle）。
2. 把 AAR 放进 `app/libs/`，等 Gradle Sync 完成。
3. 菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
4. 完成后点提示里的 **locate**，得到
   `app/build/outputs/apk/debug/app-debug.apk`。

### 方式 C — 命令行（已装 Android SDK 时）

```bash
# 1) 放好 AAR 到 app/libs/，并确保已设置 ANDROID_HOME 指向 Android SDK
# 2) 若工程没有 gradlew，先用本机 gradle 生成 wrapper：
gradle wrapper --gradle-version 8.7
# 3) 构建 debug APK
./gradlew :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

> 安装到手机：把 `app-debug.apk` 传到手机，在系统设置里允许“安装未知应用”后点击安装即可。
> debug 包用的是自动生成的调试签名，仅适合自用/测试；要上架或长期分发请自行做 release 签名。

---

## 它是怎么工作的

AMV 不是普通容器：它是一个被故意改写约定的“类 AVI”私有封装，里面装的是
**无 JPEG 头的 MJPEG**（依赖解码器内置量化/霍夫曼表）和 **IMA-ADPCM 的 AMV 变体音频**。

好消息是：**FFmpeg 原生就内置了这套编解码器**（muxer `amv`、视频 `amv`、音频 `adpcm_ima_amv`）——它正是产生/消费这些文件的同一个引擎。在 PC 上用样本验证过：FFmpeg 按本项目的配方导出的文件，结构与 OEM 官方工具一致，且能被零错误回放。

所以本 App **不自己手写视频编解码器**（那需要 bit-exact 的固定量化/霍夫曼表，难以在没有真机的情况下验证），而是调用 **FFmpegKit**（FFmpeg 的安卓封装）来跑下面这条已验证的命令：

```
ffmpeg -y -i 输入.mp4 \
  -vf "scale=W:H:force_original_aspect_ratio=decrease,pad=W:H:(ow-iw)/2:(oh-ih)/2:black,fps=FPS,format=yuvj420p" \
  -c:v amv -strict -1 \
  -c:a adpcm_ima_amv -ar 22050 -ac 1 -block_size (22050/FPS) \
  -f amv 输出.amv
```

（源没有音轨时，会自动用 `anullsrc` 注入一路 22050Hz 单声道静音，因为 AMV 必须恰好有 1 视频 + 1 音频两条流。）

**反向（AMV → MP4）** 同样用 FFmpeg：它能 demux 这种“私有破坏过”的 AMV、解码内置表的 MJPEG 与
ADPCM 音频，再重新编码成通用的 H.264 + AAC。已在 PC 端用样本验证（产物时长正确、可正常播放）：

```
ffmpeg -y -i 输入.amv \
  -c:v libx264 -pix_fmt yuv420p -crf 23 \
  -c:a aac -b:a 96k -ar 22050 \
  -movflags +faststart -f mp4 输出.mp4
```

> 反向用到 `libx264`，它在 ffmpeg-kit 的 **full / full-gpl** 构建里（CI 默认下载的就是 full-gpl）；
> 若改用不含视频编码器的 **min** 构建，AMV→MP4 会失败、MP4→AMV 仍可用。

---

## 一次性准备：放入 FFmpegKit 的 AAR（**仅本地构建需要**）

> 如果你走的是**方式 A（GitHub 云端构建）**，可以**跳过本节**——云端会自动下载这个库。
> 只有在自己电脑上用 Android Studio / 命令行构建（方式 B / C）时，才需要手动放好它。

官方 `com.arthenica:ffmpeg-kit-*` 构件已于 2025 年退役并从公共仓库下架，所以本地构建时
**项目默认无法直接编译，你需要自己提供这个库**。做法：

1. 拿到任意一个 **ffmpeg-kit 的 AAR**（`full` / `full-gpl` / `min` 均可，版本 ≥ 4.5）。
   本项目用到的 `amv` / `adpcm_ima_amv` 都是标准 FFmpeg 的一部分，任何常规构建都包含。
2. 把它放到 **`app/libs/`** 目录（文件名随意，`*.aar` 会被自动包含）。
3. 直接在 Android Studio 里 Build / Run。

`app/build.gradle` 已经帮你补好了本地 AAR 不携带的传递依赖
（`com.arthenica:smart-exception-java:0.2.1`），无需额外操作。

> **一个现成的下载地址**（社区在官方下架后重新上传的 full-gpl 构建）：
> `https://github.com/NooruddinLakhani/ffmpeg-kit-full-gpl/releases/download/v1.0.0/ffmpeg-kit-full-gpl.aar`
> 下载后改名放进 `app/libs/` 即可。这是第三方上传、GPL-v3 许可、自用没问题；
> 链接若失效，可在 GitHub 搜索仍在维护的 ffmpeg-kit fork（如 `RebootMotion/ffmpeg-kit-fork`、
> `JamaisMagic/ffmpeg-kit-16KB`），或用官方仓库脚本配合 NDK 自行编译。

---

## 编译环境

| 项目 | 版本 |
|---|---|
| Android Gradle Plugin | 8.5.2 |
| Gradle | 8.7 |
| Kotlin | 1.9.24 |
| JDK | 17 |
| compileSdk / targetSdk | 34 |
| minSdk | 24 (Android 7.0) |

UI 用经典 View + ViewBinding（非 Compose），Material3 主题。

---

## 用法

打开 App 后，先在顶部选 **转换方向**：

**MP4 → AMV**
1. 点 **“选择 MP4 文件…”**，挑一个视频。
2. 在下拉框里选 **输出规格**（预设见下）。
3. 点 **“转换为 AMV”**，在系统对话框里选择保存位置/文件名（默认 `输入名.amv`）。
4. 等进度条走完即可。

**AMV → MP4**
1. 把方向切到 **“AMV → MP4”**（此时不需要选规格，参数区会自动隐藏）。
2. 点 **“选择 AMV 文件…”**，挑一个 `.amv`（系统选择器里用“全部文件”才看得到它）。
3. 点 **“转换为 MP4”**，选择保存位置/文件名（默认 `输入名.mp4`）。
4. 等进度条走完，得到可在任意手机/电脑播放的 MP4。

输入/输出都走 Storage Access Framework，**不需要任何存储权限**。

---

## 输出规格预设

| 预设 | 宽×高 | 帧率 | 说明 |
|---|---|---|---|
| 默认 | 160×120 | 15 | 匹配样本 DEMO2.amv |
| — | 160×128 | 15 | 高为 16 倍数，更“标准” |
| — | 208×176 | 15 | QCIF 附近 |
| — | 320×240 | 15 | QVGA，较大屏 |
| — | 160×120 | 30 | 更流畅、文件更大 |

### 为什么帧率是 15 而不是 16？

AMV 的音频每个数据块采样数 = `22050 / fps`，**必须是整数**，所以 **fps 必须整除 22050**
（合法：10、14、15、18、21、25、30…）。样本是 16fps，但 `22050/16` 不是整数，
FFmpeg 做不出来（OEM 工具靠取整硬做），因此用最接近的 **15fps** 近似。

### 其它硬约束（已在转换器内处理）

- **音频采样率锁死 22050Hz**、单声道；编码器只接受这个值。
- muxer 需要显式 `-block_size = 22050/fps`，否则报 `Invalid audio frame size`。
- 宽必须偶数（预设都取 16 倍数）；高建议 16 倍数，非 16 倍（如 120）已用 `-strict -1` 放行。

---

## 故障排查

- **编译期报找不到 `com.arthenica.ffmpegkit.*`**
  → `app/libs/` 里没有 AAR。按上面“一次性准备”放入即可。

- **运行时一选文件就闪退 / 找不到类**
  → AAR 与设备 ABI 不匹配，或用了不含所需编解码器的精简构建。换用 `full` 构建的 AAR。

- **转换失败，状态栏显示 `Invalid audio frame size`**
  → 正常情况下不会发生（已设 `-block_size`）。若你改了帧率为非整除值会触发，请用合法帧率。

- **进度条不动但最后成功**
  → 说明没能从源探测到时长（进度按帧号/总帧估算）。不影响产物，以最终“完成”为准。

- **AMV → MP4 失败，日志里有 `Unknown encoder 'libx264'`**
  → 你用的是不含视频编码器的 **min** 构建。换成 **full** 或 **full-gpl** 的 AAR（CI 默认就是 full-gpl）。

- **AMV → MP4 时进度条不动**
  → AMV 头不含可靠时长，App 会先数一遍真实帧数做进度；个别文件数不出来就显示不精确，但不影响产物。

- **生成的文件在某些播放器上打不开**
  → 这类设备的固件对尺寸/帧率挑剔。先试 **160×120@15**（最贴近样本）；不行再试 160×128。

---

## 目录结构

```
AmvConverter/
├─ AMV_FORMAT_SPEC.md         逆向规格书（格式细节全在这里）
├─ README.md                  本文件
├─ .github/workflows/
│  └─ build-apk.yml           GitHub Actions：云端自动出 APK
├─ settings.gradle
├─ build.gradle               根
├─ gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties
└─ app/
   ├─ build.gradle            （含 FFmpegKit 依赖说明）
   ├─ proguard-rules.pro
   ├─ libs/                    <-- 把 ffmpeg-kit 的 AAR 放这里
   └─ src/main/
      ├─ AndroidManifest.xml
      ├─ java/com/example/amvconverter/
      │  ├─ AmvConverter.kt    双向转换引擎（MP4↔AMV，FFmpegKit + 验证过的配方）
      │  └─ MainActivity.kt    UI 与文件流程
      └─ res/...
```
